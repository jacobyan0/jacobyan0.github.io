import os
import sys
import time
import signal
import subprocess

PathToPython = r"C:\Users\jacob\AppData\Local\Programs\Python\Python36\python.exe"

BaseDir = "./data"
ProcessedBaseDir = "./processed"

Interval = 60

CompanyDataRefreshRate = {
    "LA" : 60,
    "DC" : 60
}

AllCompanyCityUrl = [
    [
        "LA",
        [
            ["BirdLA", "https://mds.bird.co/gbfs/los-angeles/free_bikes"],
			["LimeLA", "https://data.lime.bike/api/partners/v1/gbfs/los_angeles/free_bike_status"],
			["JumpLA", "https://la-gbfs.getwheelsapp.com/free_bike_status.json"],
			["LyftLA", "https://s3.amazonaws.com/lyft-lastmile-production-iad/lbs/lax/free_bike_status.json"],
			["SpinLA", "https://web.spin.pm/api/gbfs/v1/los_angeles/free_bike_status.json"],
			["WheelsLA", "https://la-gbfs.getwheelsapp.com/free_bike_status.json"],
                        ["DockLA",  "https://gbfs.bcycle.com/bcycle_lametro/station_status.json"],
        ]
    ],
    [
        "DC",
        [
            ["BirdDC", "https://gbfs.bird.co/dc"],
			["LimeDC", "https://data.lime.bike/api/partners/v1/gbfs/washington_dc/free_bike_status.json"],
			["JumpDC", "https://data.lime.bike/api/partners/v1/gbfs/washington_dc/free_bike_status.json"],
			["LyftDC", "https://s3.amazonaws.com/lyft-lastmile-production-iad/lbs/dca/free_bike_status.json"],
			["SpinDC", "https://web.spin.pm/api/gbfs/v1/washington_dc/free_bike_status"],
			["SkipDC", "https://us-central1-waybots-production.cloudfunctions.net/dcFreeBikeStatus"],
                        ["DockDC", "https://gbfs.capitalbikeshare.com/gbfs/en/station_status.json"],
        ]
    ]
]

processes = []

def main():
    for company in AllCompanyCityUrl:
        for city in company[1]:
            processes.append(subprocess.Popen(
                    [PathToPython, "dataExtract.py", company[0], city[0], city[1], BaseDir, str(CompanyDataRefreshRate[company[0]]), ProcessedBaseDir, PathToPython], shell=True)
                )
            print(company[0] + "-" + city[0] + " extract started.")
            time.sleep(3)
    while(True):
        i = input("Type 'exit' to end:")
        if i == "exit":
            break
    for p in processes:
        os.kill(p.pid, signal.CTRL_C_EVENT)

if __name__ == "__main__":
    # execute only if run as a script
    main()

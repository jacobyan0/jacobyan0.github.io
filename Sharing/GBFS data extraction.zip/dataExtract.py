import sys
import os
import time
import requests
import json
import subprocess


def extract(dataURL, extractBaseDir):
    resp = requests.get(url = dataURL)
    data = resp.json()
    serverTime = 0
    if "last_updated" in data:
        serverTime = data["last_updated"]
    else:
        serverTime = int(time.time())
    
    gmt = time.gmtime(serverTime)
    filename = extractBaseDir + "/" + time.strftime("%Y/%m/%d/%H/%M_%S.json", gmt)
    
    if not os.path.exists(os.path.dirname(filename)):
        os.makedirs(os.path.dirname(filename))

    if os.path.isfile(filename):
        print("Something wrong? file <" + filename + "> already exists.")
        return ("", 0)

    with open(filename, "w") as f:
        f.write(json.dumps(data))

    return (filename, serverTime)


def extractLoop(companyName, cityName, dataURL, baseDir, startTime, interval, processedBaseDir, pathToPython):
    NextTime = startTime
    while(True):
        t = time.time()
        while(t < NextTime):
            time.sleep(1)
            t = time.time()
        batchTime = NextTime
        NextTime += interval

        extractBaseDir = baseDir + "/" + companyName + "/" + cityName
        try:
            (datafilename, serverTime) = extract(dataURL, extractBaseDir)
        except:
            print(companyName + "-" + cityName + " extract failed.")
            continue
        if datafilename != "":
            subprocess.call([pathToPython, "dataProcess.py", processedBaseDir, companyName, cityName, datafilename], shell=True)

if __name__ == "__main__":

    # execute only if run as a script
    CompanyName = sys.argv[1].strip()
    CityName = sys.argv[2].strip()
    DataURL = sys.argv[3].strip()
    BaseDir = sys.argv[4].strip()
    Interval = int(sys.argv[5].strip())
    ProcessedBaseDir = sys.argv[6]
    PathToPython = sys.argv[7]
    StartTime = time.time()
    #extract.py cityname, dataURL, basedir
    extractLoop(CompanyName, CityName, DataURL, BaseDir, StartTime, Interval, ProcessedBaseDir, PathToPython)
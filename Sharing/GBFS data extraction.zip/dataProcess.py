import os
import sys
import time
import json

Vehicle_type = [
    "scooter", 
    "bike",
]

def process(baseurl, companyName, cityName, filename):
    data = {}
    with open(filename, "r") as f:
        data = json.load(f)
    serverTime = ""
    if "last_updated" in data:
        serverTime = data["last_updated"]
    else:
        serverTime = int(time.time())

    bikes = data["data"]["bikes"]
    for bike in bikes:
        id = bike["bike_id"]
        if id == "" or id.lower() == "null":
            continue
        lat = bike["lat"]
        lon = bike["lon"]
        vtype = "default"
        if "vehicle_type" in bike:
            vtype = bike["vehicle_type"]
        bikeURL = baseurl + "/" + companyName + "/" + cityName + "/" + vtype + "/" + id + ".json"
        gmt = time.gmtime(serverTime)
        
        timeStr = time.strftime("%Y-%m-%d %H-%M-%S", gmt)

        bikeAppendContent = timeStr + ": " + str(lat) + ", " + str(lon) + "\n"
        
        if not os.path.exists(os.path.dirname(bikeURL)):
            os.makedirs(os.path.dirname(bikeURL))
        with open(bikeURL, "a") as bf:
            bf.write(bikeAppendContent)

if __name__ == "__main__":
    ProcessedDataBaseURL = sys.argv[1]
    CompanyName = sys.argv[2]
    CityName = sys.argv[3]
    DataFilename = sys.argv[4] 

    process(ProcessedDataBaseURL, CompanyName, CityName, DataFilename)